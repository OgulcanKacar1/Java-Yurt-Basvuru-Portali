CREATE DATABASE YURTDB

USE YURTDB

CREATE TABLE Ogrenci (  
    ogrenciID INT AUTO_INCREMENT PRIMARY KEY,  
    ad VARCHAR(100),  
    soyad VARCHAR(100),  
    sifre VARCHAR(255),  
    mail VARCHAR(100),  
    okulNo VARCHAR(50),  
    yurtDurumu BOOLEAN,  
    odaID INT,  
    FOREIGN KEY (odaID) REFERENCES Oda(odaID)  
);  

CREATE TABLE Basvuru (  
    basvuruID INT AUTO_INCREMENT PRIMARY KEY,  
    ogrenciID INT,   
    yurtTuru VARCHAR(100),  
    durum VARCHAR(50),  
    basvuruTarihi DATE,  
    FOREIGN KEY (ogrenciID) REFERENCES Ogrenci(ogrenciID)   
);  


CREATE TABLE Oda (  
    odaID INT AUTO_INCREMENT PRIMARY KEY,  
    odaNo VARCHAR(50),  
    kat INT,  
    kapasite INT,  
    mevcutDoluluk INT,  
    yurtID INT,  
    FOREIGN KEY (yurtID) REFERENCES Yurt(yurtID)  
);  

CREATE TABLE YurtYetkilisi (  
    gorevliID INT AUTO_INCREMENT PRIMARY KEY,  
    ad VARCHAR(100),  
    soyad VARCHAR(100),  
    mail VARCHAR(100),  
    sifre VARCHAR(255)
);  

CREATE TABLE Yurt (  
    yurtID INT AUTO_INCREMENT PRIMARY KEY,  
    kategoriAdi VARCHAR(100),  
    fiyat INT
);  

INSERT INTO YURT (kategoriAdi, fiyat) VALUES ('Mavi', 65000);
INSERT INTO YURT (kategoriAdi, fiyat) VALUES ('Turuncu', 67500);
INSERT INTO YURT (kategoriAdi, fiyat) VALUES ('Bordo', 70000);

CREATE TABLE Admin (  
	adminID INT AUTO_INCREMENT PRIMARY KEY,
    kullanici_adi VARCHAR(100),  
    parola VARCHAR(255)  
);

INSERT INTO Admin(kullanici_adi, parola) VALUES ('ogulcankacar', '123456')
