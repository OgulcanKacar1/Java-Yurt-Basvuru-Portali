package com.example.DataAccess;

public class LoggedInYetkili {
    private static String ad;

    public static String getAd() {
        return ad;
    }

    public static void setAd(String yetkiliAd){
        ad = yetkiliAd;
    }
}
