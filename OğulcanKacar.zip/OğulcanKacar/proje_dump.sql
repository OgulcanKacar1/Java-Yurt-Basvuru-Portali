-- MySQL dump 10.13  Distrib 9.1.0, for Win64 (x86_64)
--
-- Host: localhost    Database: yurtdb
-- ------------------------------------------------------
-- Server version	9.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin` (
  `adminID` int NOT NULL AUTO_INCREMENT,
  `kullanici_adi` varchar(100) DEFAULT NULL,
  `parola` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`adminID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` VALUES (1,'ogulcankacar','123456');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `basvuru`
--

DROP TABLE IF EXISTS `basvuru`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `basvuru` (
  `basvuruID` int NOT NULL AUTO_INCREMENT,
  `ogrenciID` int DEFAULT NULL,
  `yurtTuru` varchar(100) DEFAULT NULL,
  `durum` varchar(50) DEFAULT NULL,
  `basvuruTarihi` date DEFAULT NULL,
  `aciklama` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`basvuruID`),
  KEY `ogrenciID` (`ogrenciID`),
  CONSTRAINT `basvuru_ibfk_1` FOREIGN KEY (`ogrenciID`) REFERENCES `ogrenci` (`ogrenciID`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `basvuru`
--

LOCK TABLES `basvuru` WRITE;
/*!40000 ALTER TABLE `basvuru` DISABLE KEYS */;
/*!40000 ALTER TABLE `basvuru` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oda`
--

DROP TABLE IF EXISTS `oda`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oda` (
  `odaID` int NOT NULL AUTO_INCREMENT,
  `odaNo` varchar(50) DEFAULT NULL,
  `kat` int DEFAULT NULL,
  `kapasite` int DEFAULT NULL,
  `mevcutDoluluk` int DEFAULT NULL,
  `yurtID` int DEFAULT NULL,
  PRIMARY KEY (`odaID`),
  KEY `yurtID` (`yurtID`),
  CONSTRAINT `oda_ibfk_1` FOREIGN KEY (`yurtID`) REFERENCES `yurt` (`yurtID`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oda`
--

LOCK TABLES `oda` WRITE;
/*!40000 ALTER TABLE `oda` DISABLE KEYS */;
INSERT INTO `oda` VALUES (2,'A106',1,3,1,2),(3,'A105',1,3,0,1),(9,'A101',1,3,0,2),(10,'A102',1,3,0,2),(11,'A103',1,3,0,2),(12,'A104',1,3,0,2),(13,'A105',1,1,0,2),(14,'B201',1,3,0,1),(15,'B202',2,3,0,1),(16,'B203',2,3,0,1),(17,'B204',2,3,0,1),(18,'B205',2,1,0,1),(19,'C301',3,3,1,3),(20,'C302',3,3,0,3),(21,'C303',3,3,0,3),(22,'C304',3,3,2,3),(23,'C305',3,3,0,3),(24,'C306',3,1,1,3),(25,'C110',1,3,0,1);
/*!40000 ALTER TABLE `oda` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ogrenci`
--

DROP TABLE IF EXISTS `ogrenci`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ogrenci` (
  `ogrenciID` int NOT NULL AUTO_INCREMENT,
  `ad` varchar(100) DEFAULT NULL,
  `soyad` varchar(100) DEFAULT NULL,
  `sifre` varchar(255) DEFAULT NULL,
  `mail` varchar(100) DEFAULT NULL,
  `okulNo` varchar(50) DEFAULT NULL,
  `yurtDurumu` tinyint(1) DEFAULT NULL,
  `odaID` int DEFAULT NULL,
  PRIMARY KEY (`ogrenciID`),
  KEY `odaID` (`odaID`),
  CONSTRAINT `ogrenci_ibfk_1` FOREIGN KEY (`odaID`) REFERENCES `oda` (`odaID`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ogrenci`
--

LOCK TABLES `ogrenci` WRITE;
/*!40000 ALTER TABLE `ogrenci` DISABLE KEYS */;
INSERT INTO `ogrenci` VALUES (3,'Oğulcan','Kacar','123456','21yöbi1015@isik.edu.tr','21yöbi1015',1,2),(4,'Tolga','Olguner','123456','21yöbi1053@isik.edu.tr','21yöbi1053',0,NULL),(5,'Faruk','Kılıç','123456','21yöbi1026@isik.edu.tr','21yöbi1026',1,24),(6,'Busenur','Artam','123456','21psko1022@isik.edu.tr','21psko1022',1,19),(14,'ornekAd','ornekSoyad','123456','ornekMail','ornekNo',0,NULL),(15,'Aysu Naz','Yanık','123456','23trad1004@isik.edu.tr','23trad1004',1,22),(16,'Sude','Demirhan','123456','22econ1019@isik.edu.tr','22econ1019',1,22),(17,'Ege','Okumuş','123456','22yöbi1030@isik.edu.tr','22yöbi1030',NULL,NULL),(18,'Ahmet  Emin','Çakır','123456','21yöbi1025@isik.edu.tr','21yöbi1025',NULL,NULL),(19,'Selahattin Berke','Kamışoğlu','123456','21yöbi1040@isik.edu.tr','21yöbi1040',NULL,NULL),(20,'Muhammet Hasan','Karabıyıkoğlu','123456','22imim1049@isikun.edu.tr','22imim1049',NULL,NULL);
/*!40000 ALTER TABLE `ogrenci` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `yurt`
--

DROP TABLE IF EXISTS `yurt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `yurt` (
  `yurtID` int NOT NULL AUTO_INCREMENT,
  `kategoriAdi` varchar(100) DEFAULT NULL,
  `fiyat` int DEFAULT NULL,
  PRIMARY KEY (`yurtID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `yurt`
--

LOCK TABLES `yurt` WRITE;
/*!40000 ALTER TABLE `yurt` DISABLE KEYS */;
INSERT INTO `yurt` VALUES (1,'Mavi',65000),(2,'Turuncu',67500),(3,'Bordo',70000);
/*!40000 ALTER TABLE `yurt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `yurtyetkilisi`
--

DROP TABLE IF EXISTS `yurtyetkilisi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `yurtyetkilisi` (
  `gorevliID` int NOT NULL AUTO_INCREMENT,
  `ad` varchar(100) DEFAULT NULL,
  `soyad` varchar(100) DEFAULT NULL,
  `mail` varchar(100) DEFAULT NULL,
  `sifre` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`gorevliID`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `yurtyetkilisi`
--

LOCK TABLES `yurtyetkilisi` WRITE;
/*!40000 ALTER TABLE `yurtyetkilisi` DISABLE KEYS */;
INSERT INTO `yurtyetkilisi` VALUES (2,'Selim','Durmuş','selim.duran@isikun.edu.tr','123456'),(3,'Murat','Koca','muratkoca@isikun.edu.tr','123456'),(5,'Kaan','Kılıç','kaan.kilic@isik.edu.tr','123456'),(7,'Cenk','Tosun','cenk.tosun@isikun.edu.tr','123456'),(9,'yetkili','yetkili','yetkili','123456');
/*!40000 ALTER TABLE `yurtyetkilisi` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-01-14  0:05:31
